﻿namespace AtividadeA
{
    partial class AtividadeA
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblidade = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            this.txtIdade = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblidade
            // 
            this.lblidade.AutoSize = true;
            this.lblidade.Location = new System.Drawing.Point(74, 50);
            this.lblidade.Name = "lblidade";
            this.lblidade.Size = new System.Drawing.Size(72, 13);
            this.lblidade.TabIndex = 0;
            this.lblidade.Text = "Digite a idade";
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(54, 113);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(110, 23);
            this.btncalcular.TabIndex = 1;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // txtIdade
            // 
            this.txtIdade.Location = new System.Drawing.Point(54, 78);
            this.txtIdade.Name = "txtIdade";
            this.txtIdade.Size = new System.Drawing.Size(110, 20);
            this.txtIdade.TabIndex = 2;
            // 
            // AtividadeA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 187);
            this.Controls.Add(this.txtIdade);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.lblidade);
            this.Name = "AtividadeA";
            this.Text = "AtividadeA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblidade;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.TextBox txtIdade;
    }
}

