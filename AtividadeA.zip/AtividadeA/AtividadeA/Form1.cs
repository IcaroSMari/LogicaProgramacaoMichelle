﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeA
{
    public partial class AtividadeA : Form
    {
        public AtividadeA()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
          //entrada
            int idade = int.Parse(txtIdade.Text);
            int meses;

            // calcule

            meses = idade * 12;

            //mostrar resultado

            MessageBox.Show("Idade em meses: " + meses);


        }
    }
}
