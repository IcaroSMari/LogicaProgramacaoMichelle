﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevisaoLogP
{
    public partial class FormExercicio4 : Form
    {
        public FormExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float salMin = float.Parse(txtSalMin.Text);
            float salFunc = float.Parse(txtSalFunc.Text);
            float resultado = salFunc /  salMin;

            lblResultado.Text = resultado.ToString();

        }
    }
}
