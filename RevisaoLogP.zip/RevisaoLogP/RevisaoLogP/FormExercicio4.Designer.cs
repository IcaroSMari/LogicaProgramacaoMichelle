﻿namespace RevisaoLogP
{
    partial class FormExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtSalMin = new System.Windows.Forms.TextBox();
            this.txtSalFunc = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(148, 239);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(148, 50);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "button1";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtSalMin
            // 
            this.txtSalMin.Location = new System.Drawing.Point(148, 165);
            this.txtSalMin.Name = "txtSalMin";
            this.txtSalMin.Size = new System.Drawing.Size(100, 20);
            this.txtSalMin.TabIndex = 1;
            // 
            // txtSalFunc
            // 
            this.txtSalFunc.Location = new System.Drawing.Point(148, 116);
            this.txtSalFunc.Name = "txtSalFunc";
            this.txtSalFunc.Size = new System.Drawing.Size(100, 20);
            this.txtSalFunc.TabIndex = 2;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(346, 149);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(35, 13);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Text = "label1";
            // 
            // FormExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 545);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtSalFunc);
            this.Controls.Add(this.txtSalMin);
            this.Controls.Add(this.btnCalcular);
            this.Name = "FormExercicio4";
            this.Text = "FormExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtSalMin;
        private System.Windows.Forms.TextBox txtSalFunc;
        private System.Windows.Forms.Label lblResultado;
    }
}