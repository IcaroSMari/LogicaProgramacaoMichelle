﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RevisaoLogP
{
    public partial class FormExercicio3 : Form
    {
        public FormExercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float baseMaior = float.Parse(txtBaseMaior.Text);
            float baseMenor = float.Parse(txtBaseMenor.Text);
            float altura = float.Parse(txtAltura.Text);

            float resultado;

            resultado = (baseMaior + baseMenor) * altura / 2;

            lblResultado.Text = resultado.ToString();
        }
    }
}
